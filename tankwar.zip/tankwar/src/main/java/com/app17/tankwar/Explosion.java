package com.app17.tankwar;

import com.app17.tankwar.gameobject.GameObject;

import java.awt.*;

public class Explosion extends GameObject {


    public Explosion(int x, int y, Image[] images) {
        super(x, y, images);
        live = true;
        new Thread(() -> {
            while (++step < images.length) {
                try {
                    Thread.sleep(25);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            live = false;

        }).start();


    }

    @Override
    public void update(Graphics g) {
        draw(g);
    }


    @Override
    public void draw(Graphics g) {
        if (live) {
            g.drawImage(images[step], x, y, null);
        }
    }


}

